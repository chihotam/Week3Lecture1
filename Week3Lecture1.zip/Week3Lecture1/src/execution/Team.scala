package execution

class Team (var offense: Int, var defense: Int){
  var score: Int = 0

}
